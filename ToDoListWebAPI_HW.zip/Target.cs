﻿namespace ToDoListWebAPI_HW
{
    public class Target
    {
        public int Id { get; set; }

        public string TargetValue { get; set; }

        public string Description { get; set; }

        public bool IsCompleted { get; set; }
    }
    //класс задач
}
